/* read an PPD42NJ sensor with Raspberry-pi
 * 
 * Copyright (c) 2017 Paul van Haastrecht <paulvha@hotmail.com>
 *
 * PPD42 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or (at your
 * option) any later version.
 *
 * PPD42 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with PPD42. If not, see <http://www.gnu.org/licenses/>.  
 */
 
/** define input-pin */
#define PIN_PM1  	23
#define PIN_PM25	22

/** define output test_pin */
#define PIN_TEST	24

/** define variable */
#define _ELAP_TIME	30			// 30 seconds for single measurement
#define _WARM_UP_TIME (3 * 60)	// wait at least 3 min before output results
#define SAVE_FILE "/tmp/ppd42.log"	// default output file

#ifdef DYLOS
#define PPD_VERSION "1.1 (with DYLOS support)"		// define version
#else
#define PPD_VERSION "1.1"		
#endif

/** PDD42 PROGRAM ROUTINES */
// handle the trigger (either low or high)
void handle_eds(int pin);

/* handle if trigger was set to react on high input */
void handle_hen(int pin);

/* handle if trigger was set to react on low input */
void handle_len(int pin);

/* determine the low pulse out (LPO) time 
 * start_low = pointer to the start time in Usec
 * reset = reset start_time to zero (1) or current-time (0).
 */
double det_lpo(double *start_low, int reset);

/* include header
 * header = indicate whether to add header in file
 * fp = open file pointer
 */
void do_header(int header, FILE *fp);

/* output the result of the measurements */
void output_results(unsigned int elapse, char * SFILE);

/* main loop to get the LPO time 
 * max_loop : number of times to repeat measurement (0 = ongoing)
 * time_sec : seconds for single measure (normally 30 seconds)
 * warm_up  : seconds for warm_up before output results (cold start is min 180 seconds)
 * SFILE : file to save information information to 
 */
void pdd_loop(int max_loop, int time_sec, int warm_up, char *SFILE);

/* calculate the PM concentration
 * 
 * p_time: time low in msec for a PM (1 or 2.5um)
 * elapse: measurement period in sec
 * 
 * Derived code samples from :
 * 	Seeed_101020012-838657.pdf
 * 	wiki.seeed.cc/Grove-Dust_Sensor */
long calculate_con(double p_time, unsigned int elapse);

/* set testpulse on output pin to the requested level
 * if TEST was enabled (-t) 
 */
void do_pulse(uint8_t level);

/** ADD-ON DYLOS ROUTINES **/
#ifdef	DYLOS
# include "dylos.h"

/* Read Dylos input directly */
void get_dylos_data();

#endif

/** SUPPORTING PROGRAM ROUTINES */
/* initialise the BCM library, set the pins correctly, set parameters*/
int set_init();

/* exit correctly */
void close_out(int ret);

/* return current time in microseconds */
double get_current();

/* catch signals to close out correctly */
void signal_handler(int sig_num);

/* setup signals */
void set_signals();

/* display usage / help information */
void usage(char *name, char *SFILE, int timeout, int warm_up);

/* convert string to int */
int str_to_i(char *arg);



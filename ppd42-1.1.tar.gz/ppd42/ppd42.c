/* read an PPD42NJ sensor with Raspberry-pi
 * 
 * Copyright (c) 2017 Paul van Haastrecht <paulvha@hotmail.com>
 *
 * PPD42 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or (at your
 * option) any later version.
 *
 * PPD42 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with PPD42. If not, see <http://www.gnu.org/licenses/>.  
 * 
 * compile :
 *   
 * without DYLOS : cc -o ppd42 -Wall ppd42.c -lbcm2835 -lm
 * 
 * with DYLOS : cc -o ppd42 -Wall -DDYLOS ppd42.c dylos.c -lbcm2835 -lm
 */
 
#include <bcm2835.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <getopt.h>
#include <sys/time.h>
#include <math.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "ppd42.h"
#include <stdarg.h>

/* GPIO-pin usage*/
int	pin_1 = PIN_PM1;		// GPIO pin for 1 um
int pin_25 = PIN_PM25;		// GPIO pin for 2.5 um
int pin_tst_pulse = PIN_TEST;	// support pulse for scope tst_pulse

/* to calculate LPO time */
double start_low_time_1, start_low_time_25;
double total_low_time_1, total_low_time_25;

/* output triggers */
int output_1 = 1;
int output_25 = 1;

/* debug information*/
int DEBUG = 0;
int	tst_pulse = 0;			// trigger to generate testpulse
int	count_1 = 0;			// count # samples 1um
int count_25 = 0;			// count # samples 2.5um

#ifdef DYLOS
/* DYLOS  information*/
int use_DYLOS = 0;
int	dylos_05 = 0;
int dylos_25 = 0;
#endif

/* display debug message
 * @param format : debug message to display and optional arguments
 *                 same as printf
 * @param level : priority : 1 = error, 0 = info 
 * info is only displayed if DEBUG had set for it*/

void p_printf (int level, char *format, ...)
{
    va_list arg;

    if (DEBUG || level)
    {
		va_start (arg, format);
		vfprintf (stdout, format, arg);
		va_end (arg);
    }
}
/* initialise the BCM library, set the pins correctly*/
int hw_init()
{
	// setup BCM2835
	if (!bcm2835_init())	return(1);
	
	// set pin for 1um as input and trigger on change to low.
	bcm2835_gpio_fsel(pin_1,BCM2835_GPIO_FSEL_INPT);
	bcm2835_gpio_len(pin_1);
	
	// set pin for 2.5um as input and trigger on change to low.
	bcm2835_gpio_fsel(pin_25,BCM2835_GPIO_FSEL_INPT);
	bcm2835_gpio_len(pin_25);
	
	// if tst_pulse pulse requested (set low)
	if (tst_pulse)
	{
		bcm2835_gpio_fsel(pin_tst_pulse,BCM2835_GPIO_FSEL_OUTP);
		bcm2835_gpio_write(pin_tst_pulse, LOW);
	}
	
#ifdef DYLOS	
	// open connection to Dylos
	if (use_DYLOS) return ( open_dylos(NULL) );
#endif
	return(0);
}

/**  Dylos handling routine */
#ifdef DYLOS
/* Read Dylos input and store results into global variables */
 
void get_dylos_data()
{
	char	buf[20];			// holds data as read from Dylos
	char	dylosbuf[20];		// store result
	int		ret, i, offset=0;
	char	*f;
	
	p_printf(0, "check for Dylos data.\n");
		
	// reset Dylos readings 
	dylos_05 = dylos_25 = 0;

	// try to read from Dylos and wait 1 seconds
	ret = read_dylos(buf, 20, 1);

	// if data received 
	if (ret > 0)
	{
		for(i = 0; i < ret; i++)	// store to temp to filter out carbage
		{
			// if last byte on line
			if (buf[i] == 0xa) 
			{
				// terminate
				dylosbuf[offset] = 0x0;

				// look for seperator
				f = strchr(dylosbuf, ',');
				
				if (f != NULL)
				{
					*f++=0x0;
					
					//extract PM2.5
					dylos_25 = str_to_i(f);
				
					// extract PM0.5
					dylos_05 = str_to_i(dylosbuf);
																
					// in case of progress request
					p_printf(0, "PM0.5 = %d, PM2.5 =%d\n",dylos_05,dylos_25);
				
				}
				
				return;
			}
			
			// skip carriage return and any carbage below 'space'
			else if (buf[i] != 0xd && buf[i] > 0x1f) 

					dylosbuf[offset++] = buf[i];
		}
	}
	else if (ret == 0)
		p_printf(0, "Nothing received from Dylos.\n");

	else
		p_printf(1, "Error during reading Dylos.\n");
}
#endif

/* close out correctly and reset the hardware / release BCM2835 
 * @param ret : exit code
 */
void close_out(int ret)
{
	// deselect the pins and return to normal
	bcm2835_gpio_clr_len(pin_1);
	bcm2835_gpio_clr_hen(pin_1);
	
	bcm2835_gpio_clr_len(pin_25);
	bcm2835_gpio_clr_hen(pin_25);
	
	// if tst_pulse _output was requested 
	if (tst_pulse)	bcm2835_gpio_fsel(pin_tst_pulse,BCM2835_GPIO_FSEL_INPT);

	// close bcm2835 library
	bcm2835_close();
		
#ifdef DYLOS				
	// close Dylos
	if (use_DYLOS) close_dylos();
#endif
	exit(ret);
}

/* catch signals to close out correctly */
void signal_handler(int sig_num)
{
	switch(sig_num)
	{
		case SIGKILL:
		case SIGABRT:
		case SIGINT:
		case SIGTERM:
			printf("\nStopping PPD42 monitor.\n");
			close_out(2);
			break;
		default:
			printf("\nneglecting signal %d.\n",sig_num);
	}
}

/* setup signals */
void set_signals()
{
	struct sigaction act;
	
	memset(&act, 0x0,sizeof(act));
	act.sa_handler = &signal_handler;
	sigemptyset(&act.sa_mask);
	
	sigaction(SIGTERM,&act, NULL);
	sigaction(SIGINT,&act, NULL);
	sigaction(SIGABRT,&act, NULL);
	sigaction(SIGSEGV,&act, NULL);
	sigaction(SIGKILL,&act, NULL);
}

/* return current time in useconds */
double get_current()
{
	struct	timeval	tv;

	gettimeofday(&tv,NULL);
	
	return((tv.tv_sec * 1000000) + tv.tv_usec);
}

/* determine the low pulse out time in msec
 * @param start_low : pointer to the start time in Usec
 * @param reset :reset start_time_low to zero (1) or current-time(0).
 */
double det_lpo(double *start_low, int reset)
{
	double elapse;
	
	// only calc if first low was detected (save in ms)
	if (*start_low == 0)	elapse = 0;
	else	elapse =  (get_current() - *start_low) / 1000;
	
	p_printf(0, "%f\n",elapse);
	
	// reset start time
	if (reset)	*start_low = 0;
	else *start_low = get_current();
		
	return(elapse);
}

/* set tst_pulse on output pin to the requested level
 * if tst_pulse was enabled (-t) 
 */
void do_pulse(uint8_t level)
{
	if (tst_pulse) bcm2835_gpio_write(pin_tst_pulse, level);
}

/* handle the trigger (either low or high)
 * @param pin : either 1um or 2.5um GPIO 
 */
void handle_eds(int pin)
{
	do_pulse(HIGH);			// set tst_pulse_pin (if requested)
	
	/** 
	 * sleep 2msec to allow settlement of the pulse causing
	 * miss reading of value of zero or very low value. As we do this 
	 * on both LOW and HIGH detection it does not influence the LPO
	 */
	
	usleep(2000);
	
	// if current level is high
	if (bcm2835_gpio_lev(pin))	handle_hen(pin);
	else handle_len(pin);
	
	do_pulse(LOW);				// reset tst_pulse_pin (if requested)
	
	// clear EDS flag
	bcm2835_gpio_set_eds(pin);
}
	
/* handle if trigger was set to react on low input
 * @param pin : either 1um or 2.5um GPIO  
 */
void handle_len(int pin)
{
	// set start low time
	if (pin == pin_1)	start_low_time_1 =  get_current();
	else start_low_time_25 =  get_current();
		
	// set to trigger on high
	bcm2835_gpio_clr_len(pin);
	bcm2835_gpio_hen(pin);
}

/* handle if trigger was set to react on high input 
 * @param pin : either 1um or 2.5um GPIO 
 */
void handle_hen(int pin)
{
	// calculate total low time for 1um
	if (pin == pin_1){
		
		if (DEBUG) {
			fprintf(stderr,"h1 ");
			count_1++;
		}

		total_low_time_1 += det_lpo(&start_low_time_1, 1);
	}
	else // calcualate total low time for 2,5um
	{
		if (DEBUG) {
			fprintf(stderr,"\th2.5 ");
			count_25++;
		}

		total_low_time_25 += det_lpo(&start_low_time_25, 1);
	}
	
	// set to trigger on low	
	bcm2835_gpio_clr_hen(pin);
	bcm2835_gpio_len(pin);
}

/* calculate the PM concentration
 * 
 * @param p_time: time low in msec for a PM (1 or 2.5um)
 * @param elapse: measurement period in sec
 * 
 * Derived code samples from :
 * 	Seeed_101020012-838657.pdf
 * 	wiki.seeed.cc/Grove-Dust_Sensor
 * 
 */
long calculate_con(double p_time,  unsigned int  elapse)
{
	double ratio;

	// check that results are within a boundery (max 16% LPO)
	if (p_time > (elapse * 0.16 * 1000) || (p_time < 1))	return (0);

	/* p_time in msec
	 * elapse (sec) * 1000 = msec
	 * to percentage * 100
	 */
	ratio = (p_time / (elapse * 1000)) * 100;

	return( (long) (1.1 * pow(ratio,3)) - (3.8 * pow(ratio,2)) + (520 * ratio) + 0.62);
}

/* calculate the result
 *  @param res_1 : pointer to return results for PM 1um
 *  @param res_25: pointer to return results for PM 2.5um
 *  @param elapse: measurement period in sec.
 */
void calculate_res(long *res_1, long *res_25, unsigned int elapse)
{
	// handle any low pending in current sample period to be added
	if (start_low_time_1 > 0)
		total_low_time_1 += det_lpo(&start_low_time_1, 0);
	
	if (start_low_time_25 > 0)
		total_low_time_25 += det_lpo(&start_low_time_25, 0);
	
	// calculate results 1um
	*res_1 = calculate_con(total_low_time_1,elapse);

	// calculate results for 2.5um
	*res_25 = calculate_con(total_low_time_25,elapse);
	
}

/* include header
 * @param header = indicate whether to add header in file
 * @param fp = open file pointer
 */
void do_header(int header, FILE *fp)
{
	// if 1um output was requested
	if (output_1)	
	{
		printf("1um\t");
		if ((fp > 0) && (header == 1))	fprintf(fp,"%s", "1um\t");
	}
	
	// if 2.5um output was requested
	if (output_25)
	{
		printf("2.5um\t");
		if ((fp > 0) && (header == 1))	fprintf(fp,"%s", "2.5um\t");
	}
	
#ifdef DYLOS	
	// if Dylos was requested
	if (use_DYLOS)
	{
		printf("Dylos\t\t");
		if ((fp > 0) && (header == 1))	fprintf(fp,"%s", "Dylos\t\t");		
	}
#endif
		
	// include timestamp
	printf("Time stamp\n");
	if ((fp > 0) && (header == 1))	fprintf(fp, "%s", "Time stamp \n");
	
	// close out with line
	printf("-----------------------------------\n");
	if ((fp > 0) && (header == 1))	fprintf(fp, "------------------------------------\n");
			
}

/* output the result of the measurements 
 * @param elapse: measurement period in sec.
 * @param SFILE : output file to save information if not NULL
 */
 
void output_results(unsigned int elapse, char * SFILE)
{
	long 	result_1, result_25;
	static	int header = 1;
	FILE	*fp=0;
	struct	stat buffer;
	
	// get time & date
	time_t	t; 
	time(&t);
	struct	tm	*info = localtime(&t);

	// calculate results
	calculate_res(&result_1, &result_25, elapse);
	
	// open requested output file
	if (strlen(SFILE) != 0)
	{
		// check if file exists to prevent another header
		if (stat(SFILE,&buffer) == 0)
			if (header == 1) header = 2;
			
		// open file to append
		fp = fopen(SFILE,"a");
		
		if (fp == NULL)
		{
			p_printf(1, "can not open output file %s\n",SFILE);
			close_out(1);
		}
	}
	
	// include header (on screen OR file)
	if (header)
	{
		do_header(header,fp);
	
		// only once the header.
		header = 0;
	}
	
	// if 1um output was not excluded	
	if (output_1){
		printf("%ld\t", result_1);
		if (fp > 0)	fprintf(fp, "%ld\t", result_1);
	}
	
	// if 2.5um output was not excluded
	if (output_25){
		printf("%ld\t",result_25);
		if (fp > 0)	fprintf(fp, "%ld\t", result_25);
	}
#ifdef DYLOS	
	// if Dylos output was requested
	if (use_DYLOS)
	{
		printf("%d, %d\t",dylos_05,dylos_25);
		if (fp > 0)	fprintf(fp, "%d, %d\t",dylos_05,dylos_25);

		// include tab to keep output aligned
		if (dylos_05 == 0)
		{
			printf("\t");
			if (fp > 0)	fprintf(fp, "\t");
		}
	}
#endif

	// include TIMESTAMP
	printf("%s",asctime(info));
	if (fp > 0)	fprintf(fp, "%s",asctime(info));;

	if (DEBUG)
	{
		if(count_1 > 0) {
			printf("1um   count: %d, average (ms): %f\n",count_1, total_low_time_1/count_1);
			
			if (fp > 0)
				fprintf(fp, "1um   count: %d, average (ms): %f\n",count_1, total_low_time_1/count_1);
		}
		else {
			printf("1um   count: 0\n");
			
			if (fp > 0)	fprintf(fp, "1um   count: 0\n");			
		}
		
		if(count_25 > 0){
			printf("2,5um count: %d, average (ms): %f\n",count_25, total_low_time_25/count_25);
			
			if (fp > 0)
				fprintf(fp, "2,5um count: %d, average (ms): %f\n",count_25, total_low_time_25/count_25);
		}
		else {
			printf("2,5um count: 0\n");
			
			if (fp > 0)	fprintf(fp, "2,5um count: 0\n");
		}
	}
	
	// close output file
	if (fp > 0)	fclose(fp);

	return;
}

/* main loop to get the LPO time 
 * 
 * @param max_loop : number of times to repeat measurement (0 = ongoing)
 * @param time_sec : seconds for single measure (normally 30 seconds)
 * @param warm_up  : seconds for warm_up before output results (cold start is min 180 seconds)
 * @param SFILE : file to save information to 
 */
 
void pdd_loop(int max_loop, int time_sec, int warm_up, char *SFILE)
{
	unsigned int time_loop;			// measurement time
	time_t 	time_start;				// measurement start
	int		warm_up_loop;			// how many warm_up loop
	int		loop_continue;			// how many measurement loops
	int 	last_second;			// seconds to go in debug	
	
	char	progress[]="\\|/-";		// show measurement happening
	static  unsigned int i = 0;

	// set main (repeat) loop
	if (max_loop > 0) loop_continue = max_loop;
	else loop_continue = 1;
		
	// set warm-up counter
	if (warm_up > 0) 
	{
		warm_up_loop = warm_up / time_sec;
		p_printf(1, "First warming up.\n");
	}
	else 
	{
		warm_up_loop = 0;
		p_printf(1, "Now starting measurement.\n");
	}
	
	// clear EDS flag (reset any pending before starting)
	bcm2835_gpio_set_eds(pin_1);
	bcm2835_gpio_set_eds(pin_25);
	
	// repeat measurement loop
	do
	{
		/** set starting points for measurement loop */
		// remember start moment
		time_start = time(NULL);
		time_loop = 0;
		
		// reset total low time results
		total_low_time_1 = total_low_time_25 = 0;
		
		// reset for debug
		count_1 = count_25 = 0;
		last_second = time_sec;
				
		/* as long as measurement time has not expired */
		do 
		{
			if (DEBUG)
			{
				if ( last_second != time_sec - time_loop)
				{
					last_second = time_sec - time_loop;
					p_printf(0,"seconds to go %d\n",last_second);
				}
			}
			// show progress
			else 
			{
				fprintf(stderr,"%c%c", 0x08, progress[i++]);
				fflush(stderr);
				if (i > strlen(progress)) i = 0;
			}
			
			// check on 1um level trigger
			if (bcm2835_gpio_eds(pin_1))  handle_eds(pin_1);
					
			// check on 2.5um level trigger
			if (bcm2835_gpio_eds(pin_25)) handle_eds(pin_25);
				
			// sleep 1msec (force breakpoint to other programs --- if needed)
			// if there was a detection then with usleep in handles_eds total time is 3 msec.
			usleep(1000);		
			
			// determine time measured
			time_loop = time(NULL) - time_start;
			
		} while (time_loop < time_sec);
		
		// clear and reset progress display 
		if (!DEBUG) {
			fprintf(stderr,"%c",0x08);
			fflush(stderr);
			i=0;		
		}
	
		// output results after warming up (PPD42 needs time...)
		if (warm_up_loop > 0) {
			
			// re-init values
			start_low_time_1 = start_low_time_25 = 0;
			
			if (--warm_up_loop)
				printf("Warming up. %d measurement sessions to wait.\n",warm_up_loop);
			else
				printf("Warming up finished, now starting measurement.\n");
				
		}
		else 
		{
#ifdef DYLOS
			/* get Dylos input if requested */
			if (use_DYLOS)	get_dylos_data();
#endif
			output_results(time_loop, SFILE);
		}
		// check break condition main loop
		if (max_loop > 0)	loop_continue--;

	} while(loop_continue);

}

/* convert string to int */
int str_to_i(char *arg)
{
	int	dec = 0, len, i;
	
	len = strlen(arg);
	
	for (i = 0; i < len; i++)
		dec = dec * 10 + (arg[i] - '0');
	
	return(dec);
}

/* display usage / help information */
void usage(char *name, char *SFILE, int timeout, int warm_up)
{
	printf("Version: %s \n", PPD_VERSION);
	
#ifdef DYLOS
	printf("%s [-s pin] [-p pin] [-o file] [-m #] [-w #] [-n] [-O] [-l] [-x] [-h] [-D]\n"
#else
	printf("%s [-s pin] [-p pin] [-o file] [-m #] [-w #] [-n] [-O] [-l] [-x] [-h]\n"
#endif
		"Copyright (c)  2017 Paul van Haastrecht\n"
		"\n"
		"-s, 	set different GPIO pin for 1um (default: %d)\n"
		"-p, 	set different GPIO pin for 2.5um (default: %d)\n"
		"-o, 	set different outputfile. (default: %s)\n"
		"-O, 	no output to file will be written.\n"
		"-l,	measurement repeat count(default: 0 = on-going)\n"
		"-m,	increase measurement time beyond default: %d seconds.\n"
		"-w,	set different warm-up time (default: %d seconds)\n"
		"-n, 	do NOT output 1um results.\n"
		"-x,	do NOT output 2.5um results.\n"
		"-d,	display debug info.\n"
		"-t,	enable tst_pulse-output-pulse.\n"
#ifdef DYLOS
		"-D,	include DYLOS data through USB connection.\n"
#endif
		"-h, 	show this help text.\n", 
		name, pin_1, pin_25, SFILE, timeout, warm_up);
}

int main (int argc, char **argv)
{
	int c;
	
	// pre-init variables
	int timeout = _ELAP_TIME;
	int warm_up = _WARM_UP_TIME;
	char SFILE[200] = SAVE_FILE;
	int max_loop = 0;
		
	while (1)
	{
#ifdef DYLOS
		c = getopt(argc, argv,"-s:p:o:w:l:m:nxhdOtD");
#else
		c = getopt(argc, argv,"-s:p:o:w:l:m:nxhdOt");
#endif
		if (c == -1)	break;
			
		switch (c) {
			case 's':	// change pin 1um
				pin_1 = str_to_i(optarg);
				break;
			
			case 'p':	// change pin 2.5um
				pin_25 = str_to_i(optarg);
				break;
			
			case 'l':	// set # of measurements
				max_loop = str_to_i(optarg);
				break;
			
			case 'o':	// change output file
				if (strlen(optarg) < 200)	strcpy (SFILE, optarg);
				else {
					p_printf(1,"Path is too long: %s\n",optarg);
					exit(1);
				}
				break;
			
			case 'O':	// set for NO output to file
				SFILE[0]=0x0;
				break;
			
			case 'm':	// increase # of measurement seconds
				timeout = str_to_i(optarg);
				if (timeout < 30) {
					p_printf(1,"can not set measurement time less then 30 seconds.\n");
					exit(1);
				}
				break;
			
			case 'w':	// change default warm-up time
				warm_up = str_to_i(optarg);
				break;

			case 't':	// set for tst_pulsepulse to debug
				tst_pulse=1;
				break;
			
			case 'n':	// no output 2.5um results
				if (output_1 == 0) {
					p_printf(1,"Can not exclude both 1um and 2.5um\n");
					exit(1);
				}
				output_25 = 0;
				break;
			
			case 'x':	// no output 1um results
				if (output_25 == 0) {
					p_printf(1,"Can not exclude both 1um and 2.5um\n");
					exit(1);
				}
				output_1 = 0;
				break;
#ifdef	DYLOS			
			case 'D':	// set to read DYLOS
				use_DYLOS=1;
				break;
#endif		
			case 'd':	// set for debug
				DEBUG=1;
				break;	
					
			case 'h':	// help
				usage(argv[0], SFILE,timeout,warm_up);
				exit(0);
				break;
				
			default:
				p_printf(1,"try '%s --help' for more information\n",argv[0]);
				exit(0);
				break;
			}			
	}
	
	// setup hardware
	if (hw_init())
	{
		printf("Error during initialisation.\n");
		exit(1);
	}

	p_printf(0,"DEBUG enabled.\nHardware has been initialised\n");
		
	// set to catch signals
	set_signals();
	
	// do main loop to capture information
	pdd_loop(max_loop,timeout, warm_up, SFILE);
	
	close_out(0);
	
	// to prevent -Wall option to complain
	exit(0);
}

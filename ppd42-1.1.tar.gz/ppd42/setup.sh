#! /bin/bash
# will compile the PPD42 monitor either without DYLOS or with Dylos
# support. 

PATH=/sbin:/usr/sbin:/bin:/usr/bin

case "$1" in
    ppd42)
		cc -o ppd42 -Wall ppd42.c -lbcm2835 -lm
        exit 0
        ;;

    +DYLOS)
        cc -o ppd42 -Wall -DDYLOS ppd42.c dylos.c -lbcm2835 -lm
        exit 0
        ;;
    *)
        echo "Usage: $0 ppd42|+DYLOS" >&2
        exit 3
        ;;
esac
